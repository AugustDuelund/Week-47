import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        Connection connection = null;
        String JdbcUrl ="jdbc:mysql://localhost/world?"+"autoReconnect=true&useSSL=false";
        String username = "root";
        String password = "";

        try
        {
            connection = DriverManager.getConnection(JdbcUrl, username, password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
